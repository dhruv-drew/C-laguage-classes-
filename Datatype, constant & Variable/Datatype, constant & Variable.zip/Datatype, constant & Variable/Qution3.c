#include<stdio.h>
int main(){
    int a, b, c;

    printf("Enter the first value :");
    scanf("%d", &a);

    printf("Enter the second value :");
    scanf("%d", &b);

    c = a*b;

    printf("The product is : %d \n",c);

    return 0;
}