#include<stdio.h>
int main(){
    int distance, time, valocity;

    printf("Enter the distance :");
    scanf("%d", &distance);

    printf("Enter the distance :");
    scanf("%d", &time);

    valocity = distance / time;


    printf("Enter the distance : %d", valocity);

    return 0;
    // scanf("%d", &distance);
}