#include<stdio.h>

int main(){
    int num = 2;
    // int ans = num * num * num;

    // int power = 3;
    printf("The ans is : %d",num * num * num);

    return 0;
}