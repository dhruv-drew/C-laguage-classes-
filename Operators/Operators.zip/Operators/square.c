#include<stdio.h>

int main(){
    int val, output;

    printf("Enter the value : ");
    scanf("%d", &val);

    output = val * val;

    printf("the square of the number is : %d \n", output);

    return 0;


}