#include <stdio.h>

int main() {
    int num1, num2, sum;

    printf("Enter first value : ");
    scanf("%d",&num1);

    printf("Enter first value : ");
    scanf("%d",&num2);

    sum = num1 + num2;

    printf("The sum of num1 and num2 is %d", sum);

    return 0;
}