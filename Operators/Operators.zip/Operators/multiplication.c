#include<stdio.h>

int main(){
    int val1, val2, val;

    printf("Enter the first value : ");
    scanf("%d",&val1);

    printf("Enter the first value : ");
    scanf("%d",&val2);

    val = val1 * val2;

    printf("The multiplycation of the two number is : %d", val);

    return 0;
}