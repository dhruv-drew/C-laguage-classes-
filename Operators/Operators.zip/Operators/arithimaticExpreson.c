#include<stdio.h>

int main(){
    int a = 5;
    int b = 3;
    int c = 7;
    int d = 2;
    // int ans = (a+b)*(c-d);
    printf("The ans is : %d",(a+b)*(c-d));
    return 0; 
}